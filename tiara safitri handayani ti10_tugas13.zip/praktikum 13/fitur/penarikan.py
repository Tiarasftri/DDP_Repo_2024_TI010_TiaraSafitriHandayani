import streamlit as st

st.title("Halaman Penarikan")

with st.form("Penarikan"):
    nama = st.text_input("Nama Anda")
    jumlah = st.number_input("Jumlah Penarikan (Rp.)", min_value=0)
    tanggal = st.date_input("Tanggal Penarikan")
    waktu = st.time_input("Waktu Penarikan")
    button = st.form_submit_button(label="Tarik Uang")
    if button and jumlah > 0:
        st.session_state['total_semua'].append({
            "Tipe": "Penarikan",
            "Jumlah": jumlah,
        })
        st.success(f"Anda berhasil menarik uang sebesar Rp. {jumlah}")
    else:
        st.error("Jumlah penarikan harus lebih dari 0.")

