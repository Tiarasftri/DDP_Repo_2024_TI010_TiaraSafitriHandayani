import streamlit as st

st.title("Halaman Menabung")

#form Menabung
with st.form("Menabung"):
    nama = st.text_input("Nama Anda")
    jumlah = st.number_input("jumlah (Rp.)", min_value=0)
    tanggal = st.date_input("Tanggal")
    waktu = st.time_input("Waktu")  
    button = st.form_submit_button(label="Menabung")
    if button and jumlah >= 50000:
        st.session_state['total_semua'].append({
            "Tipe": "Menabung",
            "Jumlah": jumlah,
        })
        st.success(f"anda berhasil menabung sebesar {jumlah}")
    else:
        st.error("Nominal yang anda masukkan kurang dari RP. 50.000")
