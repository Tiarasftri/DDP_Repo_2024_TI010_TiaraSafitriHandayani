import BangunDatar

BangunDatar.l_persegi(9)
BangunDatar.l_persegi_panjang(18,4)
BangunDatar.l_segitiga(8, 12)
BangunDatar.l_jajargenjang(2, 3)
BangunDatar.l_lingkaran(7)

import BangunRuang

BangunRuang.l_balok(4,6,3)
BangunRuang.l_kubus(7)
BangunRuang.l_limas(18, 9)
BangunRuang.l_prisma(8, 5)
BangunRuang.l_tabung(5, 2)

import hitung

hitung.tambah(80, 70)
hitung.kurang(50, 30)
hitung.kali(5, 60)
hitung.bagi(80, 9)
hitung.pangkat(2,5)