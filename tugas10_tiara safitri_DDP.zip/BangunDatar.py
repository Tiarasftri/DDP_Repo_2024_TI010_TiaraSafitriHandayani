import math 

#Deklarasi Fungsi 
def l_persegi(sisi):
    hitung = sisi * sisi
    print(f'Luas persegi adalah {hitung}')

def l_persegi_panjang(p, l):
    hitung = p * l
    print(f'Luas persegi panjang adalah {hitung}')

def l_segitiga(alas, tinggi):
    hitung = 1/2 * alas * tinggi
    print(f'Luas segitiga adalah {hitung}')

def l_jajargenjang(alas, tinggi):
    hitung = alas * tinggi
    print(f'Luas jajargenjang adalah {hitung}')

def l_lingkaran(r):
    hitung = r * 3.14 * r
    print(f'Luas lingkaran adalah {hitung}')